from django.contrib import admin
from .models import Hotel, Hotel_Konum



# Register your models here.


admin.site.register(Hotel)
admin.site.register(Hotel_Konum)
