from django.db import models


RATING = (
    (1, '1'),
    (2, '2'),
    (3, '3'),  
    (4, '4'),
    (5, '5'),
    (6, '6'),
    (7, '7'),
    (8, '8'),  
    (9, '9'),
    (10, '10'),
)

INDIRIM = (
    (1, 'Üye Fiyatından Yararlanılabilir'),
    (2, '%42 İndirim'),
)

# Create your models here.
class Hotel(models.Model):
    title = models.CharField(max_length=100)
    image = models.ImageField(upload_to="hotel",null=True,blank=True)
    rating = models.IntegerField(choices=RATING,default=10)
    description = models.TextField(null=True,blank=True) 
    address= models.CharField(max_length=100,default="Istanbul")
    misafir = models.IntegerField(default="1")
    day = models.IntegerField(default="1")
    price = models.DecimalField(max_digits=9999999, decimal_places=2,default="1.99")
    old_price = models.DecimalField(max_digits=9999999, decimal_places=2,default="2.99")
    secim = models.IntegerField(choices=INDIRIM,default=1)
    
    def __str__(self):
        return self.title
    
class Hotel_Konum(models.Model):
    hotel=models.ForeignKey(Hotel,on_delete=models.CASCADE)
    ozellik=models.CharField(max_length=100)
    acik_adres=models.CharField(max_length=200)
    harita=models.TextField(null=True,blank=True)

   