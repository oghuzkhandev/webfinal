from decimal import Decimal
from imaplib import _Authenticator
from django.shortcuts import redirect, render,HttpResponseRedirect
from django.contrib.auth import authenticate, login as django_login, logout
from .models import Hotel,Hotel_Konum
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import F, DecimalField, ExpressionWrapper
from .forms import SignUpForm
import random
# Create your views here.


def index(request):
    hotel = Hotel.objects.all()
    random_number = random.randint(9, 100)
    
    # Kullanıcı giriş yapmışsa
    if request.user.is_authenticated:
        # Fiyatlarda %10 indirim yap
        for h in hotel:
            h.price *= Decimal('0.9')
    
    return render(request, "core/index.html", {"hotel": hotel,"random_number":random_number})

def detail(request,id):
    detail = Hotel_Konum.objects.get(pk=id)
    return render(request,"core/hotel_detail.html",{"detail":detail})

def login(request):
    if request.method == 'POST':
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)
        if user is not None:
            django_login(request,user)
            return HttpResponseRedirect('/')
        else:
            messages.warning(request,"Login Hatası! Kullanıcı adı veya şifre yanlış.")
            return redirect ('login')
            # Return an 'invalid login' error message.
    return render(request, 'core/login.html')

def logout_view(request):
    logout(request)
    return HttpResponseRedirect('/')

def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            django_login(request, user)  # Use django_login instead of login

        else:
            form.errors
            return redirect("signup")
        
        return HttpResponseRedirect("/")
    form = SignUpForm()
    context = {'form': form}
    return render(request, 'core/signup.html', context)