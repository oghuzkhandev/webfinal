from django.shortcuts import render
from .forms import SearchForm

def your_view(request):
    if request.method == 'POST':
        form = SearchForm(request.POST)
        if form.is_valid():
            destination = form.cleaned_data['destination']
            date = form.cleaned_data['date']
            num_guests = form.cleaned_data['num_guests']
            num_children = form.cleaned_data.get('num_children', 0)


